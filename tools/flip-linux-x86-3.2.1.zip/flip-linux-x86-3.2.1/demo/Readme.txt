The JniIspDemo.exe program has been built to run on an AT90USB1287
device. The ISP sequence runs on USB port

To change these settings, modify the JniIspDemo.cpp file in the folder.
The ISP actions are controlled by a set of defines in the JniIspDemo.h file.
